
export type ResponseType = 'text' | 'image';
